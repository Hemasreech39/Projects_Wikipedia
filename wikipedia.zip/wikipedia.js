let inputE1 = document.getElementById("inputE1");
let divCard = document.createElement("div");



function renderUser(items) {
    for (let each of items) {
        let { title, link, description } = each
        let heading1 = document.createElement("h5");
        let link1 = document.createElement("a");
        let para1 = document.createElement("p");
        
        heading1.textContent = title;
        link1.textContent = link;
        link1.href = link;
        para1.textContent=description;
        divCard.appendChild(heading1);
        divCard.appendChild(link1);
        divCard.appendChild(para1);
        document.body.appendChild(divCard);
        heading1.classList.add("h5");
        link1.classList.add("link");
        para1.classList.add("para");
        
    
    }      
}


inputE1.addEventListener("keydown", function (e) {
    if (e.key == "Enter") {
        divCard.textContent = "";
        let a = inputE1.value;
        console.log(a);
        fetch(`https://apis.ccbp.in/wiki-search?search=${a}`).then(function (response) {
            return response.json()
        }).then(function (result) {
            console.log(result);
            renderUser(result.search_results);
        })
    }
})


